python run_td_likelihood.py \
            --unlensed-event-name GW170104 \
            --unlensed-event-time 1167559936.616551 \
            --unlensed-ifos H1 L1 \
            --unlensed-recdata-files H1_wf_signal.dat L1_wf_signal.dat \
            --lensed-event-name GW170814 \
            --lensed-event-time 1186741861.533669 \
            --lensed-ifos H1 L1 V1 \
            --lensed-recdata-files H1_wf_signal_L.dat L1_wf_signal_L.dat V1_wf_signal_L.dat \
            --prior-file priors.prior