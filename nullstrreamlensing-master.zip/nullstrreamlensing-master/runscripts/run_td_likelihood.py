"""
This program runs time-domain likelihood for a given morse phase shift.  
"""
import os
os.environ["MKL_NUM_THREADS"] = "4" 
os.environ["NUMEXPR_NUM_THREADS"] = "4" 
os.environ["OMP_NUM_THREADS"] = "4" 

import numpy as np
import argparse
from configparser import ConfigParser
import bilby
import lal
from likelihoods import StandardLikelihoodTDForSingleImage
import utils

__author__ = "Soumen Roy <soumen.roy@ligo.org>"
__program__ = "run_td_likelihood"


usage = """ 
run_td_likelihood  \
            --unlensed-event-name GW170104 \
            --unlensed-event-time 1167559936.616551 \
            --unlensed-ifos H1, L1 \
            --unlensed-recdata-files H1_wf_signal.dat, L1_wf_signal.dat \
            --lensed-event-name GW170814 \
            --lensed-event-time 1186741861.533669 \
            --lensed-ifos H1, L1, V1 \
            --lensed-recdata-files H1_wf_signal_L.dat, L1_wf_signal_L.dat, V1_wf_signal_L.dat \
            --prior-file priors.prior
"""


parser = argparse.ArgumentParser(description=__doc__[1:], \
    formatter_class=argparse.ArgumentDefaultsHelpFormatter, usage=usage)


parser.add_argument("--unlensed-event-name",
                type=str, default='UnlensedEvent', action="store", 
                help="Provide the name of the unlensed event. OPTIONAL")

parser.add_argument("--unlensed-event-time",
                type=float, default=None, action="store", 
                help="Provide the event time of the unlensed event. REQUIRED")

parser.add_argument("--unlensed-ifos",
                default=[], nargs='+', type=str,
                help="Provide the name of the detectors in which the unlensed "
                     "event is observed the. REQUIRED")

parser.add_argument("--unlensed-recdata-files",
                default=[], nargs='+', type=str,
                help="Supply the name of the reconstructed data files for each"
                     "detector. The first and second column must be the gps time"
                     "and reconstruted whiten data. REQUIRED")

parser.add_argument("--lensed-event-name",
                type=str, default='LensedEvent', action="store", 
                help="Provide the name of the unlensed event. OPTIONAL")

parser.add_argument("--lensed-event-time",
                type=float, default=None, action="store", 
                help=" Provide the event time of the lensed event. REQUIRED")

parser.add_argument("--lensed-ifos",
                default=[], nargs='+', type=str,
                help="Provide the name of the detectors in which the unlensed "
                     "event is observed the. REQUIRED")

parser.add_argument("--lensed-recdata-files",
                default=[], nargs='+', type=str,
                help="Supply the name of the reconstructed data files for each"
                     "detector. The first and second column must be the gps time"
                     "and reconstruted whiten data. REQUIRED")

parser.add_argument("--prior-file",
                type=str, default=None, required=True, action="store",
                help="Supply the name of the prior file. REQUIRED")

parser.add_argument("--outdir-name",
                type=str, default='test', action="store",
                help="Supply the name of the directory for saving the results. OPTIONAL")

parser.add_argument("--label-name",
                type=str, default='simpletd', action="store",
                help="Supply the label name for the results. OPTIONAL")




args = parser.parse_args()
dur = 4.0
start = 2.5
end = dur - start

# load unlensed event data
wf_dic = {}
for det, fname in zip(args.unlensed_ifos, args.unlensed_recdata_files):
    wf_dic[ det ] = utils.load_data( fname, args.unlensed_event_time, start=start, end=end )

# load lensed event data
wf_dicL = {}
for det, fname in zip(args.lensed_ifos, args.lensed_recdata_files):
    wf_dicL[ det ] = utils.load_data( fname, args.lensed_event_time, start=start, end=end )




deltaT = wf_dicL[ det ]['times'][1] - wf_dicL[ det ]['times'][0]
sampling_rate = int(1.0/deltaT)
length = int(dur*sampling_rate)


# Load the prior file
priors = bilby.core.prior.PriorDict(filename=args.prior_file)
priors['time'].minimum += args.unlensed_event_time
priors['time'].maximum += args.unlensed_event_time
priors['timeL'].minimum += args.lensed_event_time
priors['timeL'].maximum += args.lensed_event_time


if priors['phase']._is_fixed:
    for det in list(wf_dicL.keys()):
        data = np.fft.rfft( wf_dicL[det]['strain'])
        data *= np.exp(1j*priors['phase'].peak)
        data = np.fft.irfft( data, n=length )
        wf_dicL[det]['strain'] = data
        
    # remove phase from prior dict
    priors.pop('phase')

# Set up the time-domain likelihood
likelihood = StandardLikelihoodTDForSingleImage(wf_dic, wf_dicL, args.unlensed_event_time, args.lensed_event_time, deltaT)
        
# run sampler
result = bilby.run_sampler(
    likelihood=likelihood, priors=priors, sampler='pymultinest', npoints=2048, seed=61, resume=True, \
     outdir=args.outdir_name, label=args.label_name)
result.plot_corner()


# Calculate energy data
energy_calculator = utils.EnergyCalculatorTDSingleImage(wf_dic, wf_dicL, \
                               args.unlensed_event_time, args.lensed_event_time, deltaT)
ps = result.posterior.values
keys = result.posterior.keys()
nparams = len(keys)

filename = args.outdir_name+'/energies.dat'
eng_arr = []
for ii in range(ps.shape[0] ):
    sample_values = ps[ii]
    dic = { keys[jj]: sample_values[jj] for jj in range(nparams)}
    energy_calculator.parameters = dic
    eng_arr.append( energy_calculator.calculate_energies() )
eng_arr = np.array(eng_arr)
np.savetxt( filename, eng_arr )

    
    
