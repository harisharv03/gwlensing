from __future__ import division
import numpy as np
import scipy as sp
import pycwt
import h5py
import lal
import lalsimulation as lalsim
#from ligo.gracedb.rest import GraceDb
import pycbc
import pycbc.psd


__author__ = "Soumen Roy <soumen.roy@ligo.org>"



waveforms_list = ["EOBNRv2HM", "SEOBNRv4HM", "SEOBNRv4PHM", "IMRPhenomHM", "IMRPHenomPv3HM"] 


class MiscellaneousUtils(object):
    """
    This Class conatains the miscellaneous utils for generating the waveform using LALSimulation,
    time-frquency path, summing the energies along the scaled tracks.
    """
    
    _LAL_DICT_PARAMS = {"Lambda1": "lambda1", "Lambda2": "lambda2", "ampO": "ampO", "phaseO": "phaseO"}
    _LAL_DICT_PTYPE = {"Lambda1": lal.DictInsertREAL8Value, "Lambda2": lal.DictInsertREAL8Value, "ampO": lal.DictInsertINT4Value, "phaseO": lal.DictInsertINT4Value}
    
    
    def __init__(self, phiref=0., deltaT=1./4096., mass1=10.*lal.MSUN_SI,
            mass2=10.*lal.MSUN_SI, spin1x=0., spin1y=0., spin1z=0.,
            spin2x=0., spin2y=0., spin2z=0., fmin=15., fref=0., dist=1.e6*lal.PC_SI*300,
            iota=lal.PI/4, lambda1=0., lambda2=0., waveFlags=None, nonGRparams=None,
            ampO=-1, phaseO=-1, approx="SEOBNRv4HM", 
            noise_model=None,
            theta=0., phi=0., psi=0., tref=0., radec=False, detector="H1", event_time=1134604817,
            deltaF=0.2, fmax=2048., nr_hdf5_filepath=None):
        
        self.phiref = phiref
        self.deltaT = deltaT
        self.mass1 = mass1
        self.mass2 = mass2
        self.spin1x = spin1x
        self.spin1y = spin1y
        self.spin1z = spin1z
        self.spin2x = spin2x
        self.spin2y = spin2y
        self.spin2z = spin2z
        self.fmin = fmin
        self.fref = fref
        self.dist = dist
        self.iota = iota
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.waveFlags = waveFlags
        self.nonGRparams = nonGRparams
        self.ampO = ampO
        self.phaseO = phaseO
        self.approx = approx
        self.theta = theta     # DEC.  DEC =0 on the equator; the south pole has DEC = - pi/2
        self.phi = phi         # RA.   
        self.psi = psi
        # FIXME: make into property
        self.longAscNodes = 0.0
        # FIXME: Allow to be a value at some point
        self.eccentricity = 0.0
        self.meanPerAno = 0.0
        # Event time at geocentric coordinate
        self.event_time = event_time
        # Event time at detector coordinate
        self.det_event_time = event_time
        self.tref = tref
        self.radec = radec
        self.detector = detector
        self.deltaF=deltaF
        self.fmax=fmax
        
        self.nr_hdf5_filepath = nr_hdf5_filepath
        
        self.noise_model = noise_model
        self.frame_type = None
        self.channel_name = None
        self.chunk_length = None
        self.mode_list = None
        
        self.alpha_arr = None
        self.track_max_length = None
        self.track_end_frequency = None
        
        # Parameters for CWT
        self.cwt_fhigh = None
        # Admissibility constant
        self.wavelet_Cg = None
        
        self.gracedb_id = None
        
        
    def to_lal_dict(self):
        """
        This funtion returns LAL dictonary object which contains
        the tidal parameters, amplitude order, phase order, and
        GR corrections parameters.
        """
        extra_params = lal.CreateDict()
        for k, p in MiscellaneousUtils._LAL_DICT_PARAMS.items():
            typfunc = MiscellaneousUtils._LAL_DICT_PTYPE[k]
            typfunc(extra_params, k, getattr(self, p))
        
        if self.nonGRparams != None:
            for key in self.nonGRparams.keys():
                f = getattr(lalsim, 'SimInspiralWaveformParamsInsertNonGRDChi'+ key[-1])
                f(extra_params, self.nonGRparams[key]) 
            
            
        # Properly add tidal parammeters
        lalsim.SimInspiralWaveformParamsInsertTidalLambda1(extra_params, self.lambda1)
        lalsim.SimInspiralWaveformParamsInsertTidalLambda2(extra_params, self.lambda2)
        
        # Activate the specified modes
        if self.mode_list is not None:
            ma = lalsim.SimInspiralCreateModeArray()
            for l, m in self.mode_list:
                lalsim.SimInspiralModeArrayActivateMode(ma, l, m)
            lalsim.SimInspiralWaveformParamsInsertModeArray(extra_params, ma)
            
        if self.approx == 'NR_hdf5':
            f = h5py.File(self.nr_hdf5_filepath, 'r')
            lalsim.SimInspiralWaveformParamsInsertNumRelData(extra_params, self.nr_hdf5_filepath)
            m1, m2 = f.attrs['mass1'], f.attrs['mass2']
            
            spins = lalsim.SimInspiralNRWaveformGetSpinsFromHDF5File(-1, 1, self.nr_hdf5_filepath)
            self.spin1x = spins[0]
            self.spin1y = spins[1]
            self.spin1z = spins[2]
            self.spin2x = spins[3]
            self.spin2y = spins[4]
            self.spin2z = spins[5]
            f_lower = f.attrs['f_lower_at_1MSUN']
            self.fmin = f_lower/(self.mass1+self.mass2)
            mtotal = self.mass1+self.mass2
            
            self.mass1, self.mass2 = mtotal * m1/(m1+m2), mtotal * m2/(m1+m2)
            f.close()
        return extra_params
    
    


    
    def _project_hplus_hcross(self, hplus, hcross):
        """
        Compute antenna factors Fplus and Fcross anmd project the polarizations
        in the detector frame.
        """
        detector = lal.cached_detector_by_prefix[self.detector]
        Fp, Fc = lal.ComputeDetAMResponse(detector.response, self.phi, \
                                    self.theta, self.psi, lal.GreenwichMeanSiderealTime(self.event_time))

        # form strain signal in detector
        hplus.data.data = Fp*hplus.data.data + Fc*hcross.data.data

        return hplus
    
    def _time_delay_from_geocenter(self, detector=None, ra=None, dec=None, gpstime=None):
        """
        Calculate the time delay (UNIT: Sec.) between the geocentre and a given detector
        for a signal from a given sky location of the source.
        
        Parameters
        ----------
        detector: str
            A string describing the detector, e.g. L1 
        ra: float
            The right-ascension of the source. UNIT: radians
        dec: float
            The declination of the source. UNIT: radians
        
        """
        
        if not any([ detector, ra, dec, gpstime ] ) == True:
            
            return lal.TimeDelayFromEarthCenter( \
                        lalsim.DetectorPrefixToLALDetector(self.detector ).location, \
                        self.phi, self.theta, self.event_time)
        else:
            return lal.TimeDelayFromEarthCenter( \
                        lalsim.DetectorPrefixToLALDetector(detector ).location, \
                        ra, dec, gpstime)
    
    

    
    def _gen_waveform(self, polarizations=False, time_domain=False, frequency_domain=False):
        
        """
        Generate time/frequency domain waveform from LALSimulation.
        
        parameters
        ----------
        polarizations: bool
            Set polarizations True to get the plus and cross polarizations.
            default is False, OPTIONAL.
        
        time_domain: bool
            Set time_domain True to get only time domain waveform even if
            the specified waveform model exists in frequency domain.
            defalult False, OPTIONAL.
            
        frequency_domain: bool
            Set frequency_domain True to get only frequency domain waveform even if
            the specified waveform model exists in time domain.
            defalult False, OPTIONAL.
        """
        
        approximant = lalsim.GetApproximantFromString( self.approx )
        extra_params = self.to_lal_dict()
        
        if lalsim.SimInspiralImplementedFDApproximants(approximant):
            if time_domain is False:
               
                hp, hc = lalsim.SimInspiralChooseFDWaveform(self.mass1*lal.MSUN_SI, self.mass2*lal.MSUN_SI, \
                         self.spin1x, self.spin1y, self.spin1z, self.spin2x, self.spin2y, self.spin2z, \
                         self.dist, self.iota, self.phiref, self.longAscNodes, self.eccentricity, \
                         self.meanPerAno, self.deltaF, self.fmin, self.fmax, self.fref, extra_params, approximant)
            else:
                hp, hc = lalsim.SimInspiralTD(self.mass1*lal.MSUN_SI, self.mass2*lal.MSUN_SI,
                         self.spin1x, self.spin1y, self.spin1z, self.spin2x, self.spin2y, self.spin2z, \
                         self.dist, self.iota, self.phiref, self.longAscNodes, self.eccentricity, \
                         self.meanPerAno, self.deltaT, self.fmin, self.fref, extra_params, approximant)

        elif lalsim.SimInspiralImplementedTDApproximants(approximant):
            hp, hc = lalsim.SimInspiralChooseTDWaveform(self.mass1*lal.MSUN_SI, self.mass2*lal.MSUN_SI,
                     self.spin1x, self.spin1y, self.spin1z, self.spin2x, self.spin2y, self.spin2z, \
                     self.dist, self.iota, self.phiref, self.longAscNodes, self.eccentricity, \
                     self.meanPerAno, self.deltaT, self.fmin, self.fref, extra_params, approximant)
            
            if frequency_domain is True:
                window = self._gen_tukey_window(hp.data.length, end=False)
                hp = pycbc.types.TimeSeries( hp.data.data[:]*window, delta_t=hp.deltaT )
                hc = pycbc.types.TimeSeries( hc.data.data[:]*window, delta_t=hc.deltaT )
                
                hp = hp.to_frequencyseries().lal()
                hc = hc.to_frequencyseries().lal()
                
        else:
                raise ValueError("Must specify valid waveform model approximant")
        
        if polarizations is False:
            return self._project_hplus_hcross(hp, hc)
        else:
            return hp, hc
        
        

        
        
