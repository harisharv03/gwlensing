# NullStreamLensing

Use of null stream statistic for identifying the lensed events
